# redis_extention.md — Week17 项目上下文

> 第十七周作业：参照 [redis-vl-python](https://github.com/redis/redis-vl-python) Extensions 设计，在本地实现四个模块。  
> 官方库仅作**行为对照**，作业代码位于本目录，不修改上游 `redisvl` 包。

---

## 常用命令

```bash
# 环境
conda activate ren
cd C:\Users\ren\Desktop\ai\homework\week17

# 依赖（见 requirements.txt）
pip install -r requirements.txt

# 无 Docker：自动使用 fakeredis（内存 Redis），可直接测试
python run_all.py

# 或分步
pytest tests/test_extensions.py -v
set USE_FAKE_REDIS=1
python demo.py

# 有 Docker 时可选真实 Redis
docker run -d --name redis-week17 -p 6379:6379 redis:latest
python demo.py

# 单模块自测
python EmbeddingsCache.py
python SemanticCache.py
python SemanticMessageHistory.py
python SemanticRouter.py
```

---

## 项目结构（目标）

```
week17/
├── redis_extention.md      # 本文件：开发约定与命令
├── 设计文档.md              # 各模块实现思路（评审用）
├── requirements.txt
├── common.py               # Redis 连接、键前缀、序列化、embedding 抽象
├── EmbeddingsCache.py
├── SemanticCache.py
├── SemanticMessageHistory.py
├── SemanticRouter.py
├── demo.py                 # 四模块串联最小示例
└── tests/                  # 可选：后续补充
```

---

## 四个扩展模块（与官方对齐）

| 作业文件 | 官方参考类 | 官方源码路径（只读对照） |
|----------|------------|-------------------------|
| `EmbeddingsCache.py` | `EmbeddingsCache` | `redisvl/extensions/cache/embeddings/embeddings.py` |
| `SemanticCache.py` | `SemanticCache` | `redisvl/extensions/cache/llm/semantic.py` |
| `SemanticMessageHistory.py` | `SemanticMessageHistory` | `redisvl/extensions/message_history/semantic_history.py` |
| `SemanticRouter.py` | `SemanticRouter` | `redisvl/extensions/router/semantic.py` |

**设计原则**：API 形状与 README / 设计文档一致；实现为**教学级简化**（同步接口为主，不实现官方全部 async / LangCache / MCP）。

---

## 架构要点（摘要）

- **精确缓存**（`EmbeddingsCache`）：文本 + 模型名 → 确定性 key，Redis 存向量，无向量检索。
- **语义能力**（其余三个）：文本 → embedding → 相似度检索 → 再回表取 payload；详见 `设计文档.md`。
- **共享**：`common.py` 中的 `RedisClient`、`EmbeddingFn`、`cosine_distance`、键命名规范。
- **向量索引**：Redis 存条目，FAISS 做相似度检索；接口与官方同步方法对齐，见 `设计文档.md`。

---

## 关键约定

### 不要修改

- 不要在本作业中直接 patch 已安装的 `site-packages/redisvl`。
- 不要将整份 `redis-vl-python` 仓库拷贝进 `week17` 提交。

### Git

- 除非用户明确要求，不执行 `git push`。

### 文档分工

| 内容 | 文件 |
|------|------|
| 命令、目录、约定 | `redis_extention.md`（本文件） |
| 模块设计、数据结构、流程 | `设计文档.md` |
| 运行说明 | `README.md`（实现阶段再写） |

### 代码质量

- 与官方对齐处：方法名、核心参数（`name`, `redis_url`, `distance_threshold`, `ttl`）保持一致。
- 每个 `.py` 文件保留 `if __name__ == "__main__"` 最小可运行示例。
- 新增依赖写入 `requirements.txt`。

---

## 对照官方时的阅读顺序

1. [Extensions 概念](https://docs.redisvl.com/en/latest/concepts/extensions.html)
2. GitHub `CLAUDE.md` → AI Extensions 四行说明
3. README 中四个 Example 代码块
4. 需要细节时再打开对应 `redisvl/extensions/...` 源文件

---

## 环境变量（可选）

| 变量 | 用途 |
|------|------|
| `REDIS_URL` | 默认 `redis://localhost:6379/0` |
| `EMBEDDING_MODEL` | 默认 `sentence-transformers/all-MiniLM-L6-v2` |
| `USE_MOCK_EMBEDDING` | `1` 时用固定维度随机/哈希向量，无 GPU、无下载模型 |

---

## 实现进度

- [x] `common.py`
- [x] `EmbeddingsCache.py`
- [x] `SemanticCache.py`
- [x] `SemanticMessageHistory.py`
- [x] `SemanticRouter.py`
- [x] `demo.py`、`requirements.txt`、`tests/test_extensions.py`
- [x] `开发日志.md`

测试：`pytest tests/test_extensions.py -v`（19 passed，使用 fakeredis）。
