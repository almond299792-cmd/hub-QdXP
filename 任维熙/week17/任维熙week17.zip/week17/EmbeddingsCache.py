"""Embeddings cache — exact key match on content + model name."""

from __future__ import annotations

from typing import Any, Iterable

import redis

from common import (
    content_to_str,
    create_redis_client,
    current_timestamp,
    deserialize_json,
    hashify,
    serialize_json,
)


class EmbeddingsCache:
    def __init__(
        self,
        name: str = "embedcache",
        ttl: int | None = None,
        redis_client: redis.Redis | None = None,
        redis_url: str = "redis://localhost:6379",
        connection_kwargs: dict | None = None,
    ) -> None:
        self.name = name
        self.ttl = ttl
        self._redis = create_redis_client(redis_client, redis_url, connection_kwargs)
        self._keys_key = f"{name}:__keys__"

    def _entry_id(self, content: bytes | str, model_name: str) -> str:
        return hashify(content_to_str(content), model_name)

    def _make_key(self, entry_id: str) -> str:
        return f"{self.name}:{entry_id}"

    def _store_key(self, key: str) -> None:
        self._redis.sadd(self._keys_key, key)

    def _forget_key(self, key: str) -> None:
        self._redis.srem(self._keys_key, key)

    def set(
        self,
        content: bytes | str,
        model_name: str,
        embedding: list[float],
        metadata: dict | None = None,
        ttl: int | None = None,
    ) -> str:
        entry_id = self._entry_id(content, model_name)
        key = self._make_key(entry_id)
        record = {
            "entry_id": entry_id,
            "content": content_to_str(content),
            "model_name": model_name,
            "embedding": embedding,
            "inserted_at": current_timestamp(),
            "metadata": metadata,
        }
        ttl = ttl if ttl is not None else self.ttl
        payload = serialize_json(record)
        if ttl:
            self._redis.setex(key, ttl, payload)
        else:
            self._redis.set(key, payload)
        self._store_key(key)
        return entry_id

    def _parse_entry(self, raw: bytes | None) -> dict | None:
        if not raw:
            return None
        data = deserialize_json(raw)
        if data is None:
            return None
        return data

    def get_by_key(self, key: str) -> dict | None:
        raw = self._redis.get(key)
        entry = self._parse_entry(raw)
        if entry and self.ttl:
            self._redis.expire(key, self.ttl)
        return entry

    def get(self, content: bytes | str, model_name: str) -> dict | None:
        entry_id = self._entry_id(content, model_name)
        return self.get_by_key(self._make_key(entry_id))

    def exists(self, content: bytes | str, model_name: str) -> bool:
        return self.get(content, model_name) is not None

    def exists_by_key(self, key: str) -> bool:
        return self._redis.exists(key) > 0

    def drop(self, content: bytes | str, model_name: str) -> None:
        entry_id = self._entry_id(content, model_name)
        self.drop_by_key(self._make_key(entry_id))

    def drop_by_key(self, key: str) -> None:
        self._redis.delete(key)
        self._forget_key(key)

    def mget(self, contents: Iterable[bytes | str], model_name: str) -> list[dict | None]:
        return [self.get(c, model_name) for c in contents]

    def mget_by_keys(self, keys: list[str]) -> list[dict | None]:
        return [self.get_by_key(k) for k in keys]

    def mset(self, items: list[dict], ttl: int | None = None) -> list[str]:
        ids = []
        for item in items:
            eid = self.set(
                item["content"],
                item["model_name"],
                item["embedding"],
                metadata=item.get("metadata"),
                ttl=ttl,
            )
            ids.append(eid)
        return ids

    def mexists(self, contents: Iterable[bytes | str], model_name: str) -> list[bool]:
        return [self.exists(c, model_name) for c in contents]

    def mdrop(self, contents: Iterable[bytes | str], model_name: str) -> None:
        for c in contents:
            self.drop(c, model_name)

    def clear(self) -> None:
        keys = self._redis.smembers(self._keys_key)
        if keys:
            self._redis.delete(*keys)
        self._redis.delete(self._keys_key)

    def set_ttl(self, ttl: int | None = None) -> None:
        self.ttl = ttl
        if ttl is None:
            return
        for key in self._redis.smembers(self._keys_key):
            self._redis.expire(key, ttl)

    def expire(self, key: str, ttl: int | None = None) -> None:
        if ttl is not None:
            self._redis.expire(key, ttl)


if __name__ == "__main__":
    cache = EmbeddingsCache(name="embed_demo", ttl=3600)
    cache.clear()
    vec = [0.1] * 8
    eid = cache.set("What is machine learning?", "text-embedding-ada-002", vec)
    hit = cache.get("What is machine learning?", "text-embedding-ada-002")
    print("entry_id:", eid)
    print("hit:", hit is not None, "dims:", len(hit["embedding"]) if hit else 0)
