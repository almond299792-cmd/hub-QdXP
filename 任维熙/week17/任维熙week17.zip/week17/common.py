"""Shared utilities for Week17 Redis extensions."""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any, Iterable, Protocol, runtime_checkable

import numpy as np

try:
    import faiss
except ImportError as exc:  # pragma: no cover
    raise ImportError("faiss-cpu is required: pip install faiss-cpu") from exc

try:
    import redis
except ImportError as exc:  # pragma: no cover
    raise ImportError("redis is required: pip install redis") from exc


INDEX_DIR = Path(__file__).resolve().parent / ".index"
DEFAULT_REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
USE_MOCK_EMBEDDING = os.environ.get("USE_MOCK_EMBEDDING", "1") == "1"
VECTOR_INDEX_PERSIST = os.environ.get("VECTOR_INDEX_PERSIST", "1") == "1"
DEFAULT_MOCK_DIMS = 384


def current_timestamp() -> float:
    return time.time()


def hashify(*parts: Any) -> str:
    """Deterministic entry id from arbitrary parts (aligned with redisvl.redis.utils.hashify)."""
    blob = ":".join(_stringify_part(p) for p in parts)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:32]


def _stringify_part(part: Any) -> str:
    if part is None:
        return ""
    if isinstance(part, bytes):
        return part.hex()
    if isinstance(part, dict):
        return json.dumps(part, sort_keys=True, ensure_ascii=False)
    return str(part)


def normalize_vector(vector: Iterable[float]) -> np.ndarray:
    arr = np.asarray(vector, dtype=np.float32).reshape(1, -1)
    faiss.normalize_L2(arr)
    return arr[0]


def l2_to_cosine_distance(l2: float) -> float:
    """Map L2 distance on unit vectors to cosine distance in [0, 2]."""
    return float(min(2.0, max(0.0, l2 * l2 / 2.0)))


def _fake_redis_client() -> redis.Redis:
    import fakeredis

    return fakeredis.FakeRedis()


def create_redis_client(
    redis_client: redis.Redis | None = None,
    redis_url: str = DEFAULT_REDIS_URL,
    connection_kwargs: dict | None = None,
) -> redis.Redis:
    if redis_client is not None:
        return redis_client

    if os.environ.get("USE_FAKE_REDIS", "0") == "1":
        return _fake_redis_client()

    kwargs = dict(connection_kwargs or {})
    kwargs.setdefault("socket_connect_timeout", 2)
    try:
        client = redis.from_url(redis_url, decode_responses=False, **kwargs)
        client.ping()
        return client
    except (redis.ConnectionError, redis.TimeoutError, OSError):
        print("[week17] 未连接 Redis，已切换 fakeredis 内存模式（无需 Docker）")
        return _fake_redis_client()


def serialize_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False)


def deserialize_json(raw: str | bytes | None) -> Any:
    if raw is None:
        return None
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8")
    return json.loads(raw)


def content_to_str(content: bytes | str) -> str:
    if isinstance(content, bytes):
        return content.hex()
    return content


def new_session_tag() -> str:
    return str(uuid.uuid4())


@runtime_checkable
class TextVectorizer(Protocol):
    dims: int
    model_name: str
    dtype: str

    def embed(self, text: str) -> list[float]: ...

    def embed_many(self, texts: list[str]) -> list[list[float]]: ...


_STOP_WORDS = frozenset(
    {"a", "an", "the", "is", "are", "was", "what", "how", "of", "in", "to", "for", "my", "your"}
)


class MockTextVectorizer:
    """Deterministic embeddings keyed by normalized token set (stop words removed)."""

    def __init__(self, dims: int = DEFAULT_MOCK_DIMS, model_name: str = "mock-embedder"):
        self.dims = dims
        self.model_name = model_name
        self.dtype = "float32"

    def _signature(self, text: str) -> str:
        tokens = re.findall(r"[a-z0-9]+", text.lower())
        words = sorted({t for t in tokens if len(t) > 1 and t not in _STOP_WORDS})
        return " ".join(words)

    def embed(self, text: str) -> list[float]:
        sig = self._signature(text)
        seed = int(hashlib.sha256(sig.encode()).hexdigest(), 16) % (2**32)
        rng = np.random.RandomState(seed)
        vec = rng.randn(self.dims).astype(np.float32)
        return normalize_vector(vec).tolist()

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        return [self.embed(t) for t in texts]


class SentenceTransformerVectorizer:
    def __init__(
        self,
        model_name: str | None = None,
        dims: int | None = None,
    ):
        model = model_name or os.environ.get(
            "EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
        )
        from sentence_transformers import SentenceTransformer

        self._model = SentenceTransformer(model)
        self.model_name = model
        self.dims = dims or self._model.get_sentence_embedding_dimension()
        self.dtype = "float32"

    def embed(self, text: str) -> list[float]:
        vec = self._model.encode(text, convert_to_numpy=True)
        return normalize_vector(vec).tolist()

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        vecs = self._model.encode(texts, convert_to_numpy=True)
        return [normalize_vector(v).tolist() for v in vecs]


def default_vectorizer() -> TextVectorizer:
    if USE_MOCK_EMBEDDING:
        return MockTextVectorizer()
    return SentenceTransformerVectorizer()


class VectorIndex:
    """FAISS-backed vector index with entry_id mapping."""

    def __init__(self, name: str, dim: int, *, persist: bool | None = None):
        self.name = name
        self.dim = dim
        self.persist = VECTOR_INDEX_PERSIST if persist is None else persist
        self._index = faiss.IndexFlatL2(dim)
        self._entry_ids: list[str] = []
        self._active: set[str] = set()
        if self.persist:
            INDEX_DIR.mkdir(parents=True, exist_ok=True)

    @property
    def faiss_path(self) -> Path:
        return INDEX_DIR / f"{self.name}.faiss"

    @property
    def map_path(self) -> Path:
        return INDEX_DIR / f"{self.name}.map.json"

    def add(self, entry_id: str, vector: Iterable[float]) -> None:
        if entry_id in self._active:
            self.remove(entry_id)
        vec = normalize_vector(vector).reshape(1, -1)
        self._index.add(vec)
        self._entry_ids.append(entry_id)
        self._active.add(entry_id)
        if self.persist:
            self.save()

    def search(self, vector: Iterable[float], k: int = 10) -> list[tuple[str, float]]:
        if self._index.ntotal == 0:
            return []
        q = normalize_vector(vector).reshape(1, -1)
        k = min(k, self._index.ntotal)
        distances, indices = self._index.search(q, k)
        results: list[tuple[str, float]] = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < 0 or idx >= len(self._entry_ids):
                continue
            entry_id = self._entry_ids[int(idx)]
            if entry_id in self._active:
                results.append((entry_id, float(dist)))
        return results

    def remove(self, entry_id: str) -> None:
        if entry_id in self._active:
            self._active.discard(entry_id)

    def clear(self) -> None:
        self._index = faiss.IndexFlatL2(self.dim)
        self._entry_ids = []
        self._active = set()
        if self.faiss_path.exists():
            self.faiss_path.unlink()
        if self.map_path.exists():
            self.map_path.unlink()

    def save(self) -> None:
        if self._index.ntotal == 0:
            return
        self.faiss_path.parent.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._index, str(self.faiss_path))
        payload = {"entry_ids": self._entry_ids, "active": list(self._active)}
        self.map_path.write_text(json.dumps(payload), encoding="utf-8")

    def load(self) -> None:
        if not self.faiss_path.exists() or not self.map_path.exists():
            return
        self._index = faiss.read_index(str(self.faiss_path))
        payload = json.loads(self.map_path.read_text(encoding="utf-8"))
        self._entry_ids = payload.get("entry_ids", [])
        self._active = set(payload.get("active", []))

    def rebuild(self) -> None:
        """Rebuild FAISS from active ids (after removals)."""
        active_ids = [eid for eid in self._entry_ids if eid in self._active]
        if not active_ids:
            self.clear()
            return
        # Cannot recover vectors without storage; callers should clear instead.
        pass
