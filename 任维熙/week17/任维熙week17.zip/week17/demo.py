"""Minimal demo for four Redis extensions."""

from __future__ import annotations

import os

os.environ.setdefault("USE_MOCK_EMBEDDING", "1")
os.environ.setdefault("VECTOR_INDEX_PERSIST", "0")

from common import create_redis_client
from EmbeddingsCache import EmbeddingsCache
from SemanticCache import SemanticCache
from SemanticMessageHistory import SemanticMessageHistory
from SemanticRouter import DistanceAggregationMethod, Route, RoutingConfig, SemanticRouter


def _backend_label(client) -> str:
    mod = type(client).__module__
    return "fakeredis (内存)" if "fakeredis" in mod else "redis (TCP)"


def main() -> None:
    redis_client = create_redis_client()
    print(f"Redis 后端: {_backend_label(redis_client)}\n")

    print("=== EmbeddingsCache ===")
    ec = EmbeddingsCache(name="demo_embed", ttl=3600, redis_client=redis_client)
    ec.clear()
    eid = ec.set("What is machine learning?", "text-embedding-ada-002", [0.1] * 384)
    hit = ec.get("What is machine learning?", "text-embedding-ada-002")
    print("entry_id:", eid, "| cache hit:", hit is not None)

    print("\n=== SemanticCache ===")
    sc = SemanticCache(
        name="demo_llm",
        distance_threshold=0.5,
        overwrite=True,
        redis_client=redis_client,
    )
    sc.store(prompt="What is the capital city of France?", response="Paris")
    hits = sc.check(prompt="What is France's capital city?")
    print("hits:", hits[0]["response"] if hits else "none")

    print("\n=== SemanticMessageHistory ===")
    mh = SemanticMessageHistory(
        name="demo_mh",
        overwrite=True,
        distance_threshold=0.8,
        redis_client=redis_client,
    )
    mh.add_messages(
        [
            {"role": "user", "content": "hello, how are you?"},
            {"role": "llm", "content": "I'm doing fine, thanks."},
            {"role": "user", "content": "what is the weather going to be today?"},
            {"role": "llm", "content": "I don't know"},
        ]
    )
    print("recent:", mh.get_recent(top_k=1))
    rel = mh.get_relevant("what is the weather going to be today", top_k=1)
    print("relevant:", rel)

    print("\n=== SemanticRouter ===")
    routes = [
        Route(
            name="greeting",
            references=["hello", "hi", "Hi, good morning"],
            distance_threshold=0.8,
        ),
        Route(name="farewell", references=["bye", "goodbye"], distance_threshold=0.8),
    ]
    router = SemanticRouter(
        name="demo_router",
        routes=routes,
        overwrite=True,
        redis_client=redis_client,
        routing_config=RoutingConfig(
            aggregation_method=DistanceAggregationMethod.min
        ),
    )
    match = router("Hi, good morning")
    print("route:", match)

    print("\n全部演示完成。")


if __name__ == "__main__":
    main()
