"""Semantic router for intent / topic classification."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import redis
import yaml

from common import (
    VectorIndex,
    create_redis_client,
    default_vectorizer,
    deserialize_json,
    hashify,
    l2_to_cosine_distance,
    serialize_json,
    TextVectorizer,
)


class DistanceAggregationMethod(Enum):
    avg = "avg"
    min = "min"
    sum = "sum"


@dataclass
class Route:
    name: str
    references: list[str]
    metadata: dict = field(default_factory=dict)
    distance_threshold: float = 0.5

    def __post_init__(self) -> None:
        if not self.name or not self.name.strip():
            raise ValueError("Route name must not be empty")
        if not self.references:
            raise ValueError("References must not be empty")
        if any(not ref.strip() for ref in self.references):
            raise ValueError("All references must be non-empty strings")
        if not 0 < self.distance_threshold <= 2:
            raise ValueError("distance_threshold must be in (0, 2]")


@dataclass
class RouteMatch:
    name: str | None = None
    distance: float | None = None


@dataclass
class RoutingConfig:
    max_k: int = 1
    aggregation_method: DistanceAggregationMethod = DistanceAggregationMethod.avg


class SemanticRouter:
    def __init__(
        self,
        name: str,
        routes: list[Route],
        vectorizer: TextVectorizer | None = None,
        routing_config: RoutingConfig | None = None,
        redis_client: redis.Redis | None = None,
        redis_url: str = "redis://localhost:6379",
        overwrite: bool = False,
        connection_kwargs: dict | None = None,
    ) -> None:
        self.name = name
        self.routes = {r.name: r for r in routes}
        self._vectorizer = vectorizer or default_vectorizer()
        self.routing_config = routing_config or RoutingConfig()
        self._redis = create_redis_client(redis_client, redis_url, connection_kwargs)
        self._vector_index = VectorIndex(name, self._vectorizer.dims)
        self._meta_key = f"{name}:routes_meta"
        self._refs_set = f"{name}:refs"

        if overwrite:
            self.clear()
            self._index_references()
        else:
            self._vector_index.load()
            if self._vector_index._index.ntotal == 0:
                self._index_references()

    def _index_references(self) -> None:
        for route in self.routes.values():
            for ref in route.references:
                self._add_reference(route.name, ref)

    def _ref_key(self, reference_id: str) -> str:
        return f"{self.name}:ref:{reference_id}"

    def _add_reference(self, route_name: str, reference: str) -> str:
        reference_id = hashify(route_name, reference)
        vector = self._vectorizer.embed(reference)
        record = {
            "reference_id": reference_id,
            "route_name": route_name,
            "reference": reference,
            "key": self._ref_key(reference_id),
        }
        key = record["key"]
        self._redis.set(key, serialize_json(record))
        self._redis.sadd(self._refs_set, reference_id)
        self._vector_index.add(reference_id, vector)
        self._persist_meta()
        return reference_id

    def _persist_meta(self) -> None:
        meta = {
            "routes": {
                name: {
                    "name": r.name,
                    "references": r.references,
                    "metadata": r.metadata,
                    "distance_threshold": r.distance_threshold,
                }
                for name, r in self.routes.items()
            },
            "routing_config": {
                "max_k": self.routing_config.max_k,
                "aggregation_method": self.routing_config.aggregation_method.value,
            },
        }
        self._redis.set(self._meta_key, serialize_json(meta))

    def _aggregate(self, distances: list[float], method: DistanceAggregationMethod) -> float:
        if not distances:
            return float("inf")
        if method == DistanceAggregationMethod.min:
            return min(distances)
        if method == DistanceAggregationMethod.sum:
            return sum(distances)
        return sum(distances) / len(distances)

    def _route_candidates(
        self,
        statement: str | None,
        vector: list[float] | None,
        aggregation_method: DistanceAggregationMethod | None,
        distance_threshold: float | None,
    ) -> list[RouteMatch]:
        if statement is None and vector is None:
            raise TypeError("Either statement or vector must be provided.")
        query_vec = vector or self._vectorizer.embed(statement)
        method = aggregation_method or self.routing_config.aggregation_method

        ref_hits = self._vector_index.search(query_vec, k=50)
        route_distances: dict[str, list[float]] = {}
        for ref_id, l2 in ref_hits:
            raw = self._redis.get(self._ref_key(ref_id))
            if not raw:
                continue
            ref = deserialize_json(raw)
            route_name = ref["route_name"]
            cos_dist = l2_to_cosine_distance(l2)
            route_distances.setdefault(route_name, []).append(cos_dist)

        aggregated: list[tuple[str, float]] = []
        for route_name, dists in route_distances.items():
            aggregated.append((route_name, self._aggregate(dists, method)))

        aggregated.sort(key=lambda x: x[1])
        matches: list[RouteMatch] = []
        for route_name, dist in aggregated:
            route = self.routes.get(route_name)
            if not route:
                continue
            th = route.distance_threshold
            if distance_threshold is not None:
                th = distance_threshold
            if dist <= th:
                matches.append(RouteMatch(name=route_name, distance=dist))
        return matches

    def __call__(
        self,
        statement: str | None = None,
        vector: list[float] | None = None,
        aggregation_method: DistanceAggregationMethod | None = None,
        distance_threshold: float | None = None,
    ) -> RouteMatch:
        matches = self._route_candidates(statement, vector, aggregation_method, distance_threshold)
        if matches:
            return matches[0]
        return RouteMatch(None, None)

    def route_many(
        self,
        statement: str | None = None,
        vector: list[float] | None = None,
        max_k: int | None = None,
        distance_threshold: float | None = None,
        aggregation_method: DistanceAggregationMethod | None = None,
    ) -> list[RouteMatch]:
        matches = self._route_candidates(statement, vector, aggregation_method, distance_threshold)
        limit = max_k if max_k is not None else self.routing_config.max_k
        return matches[:limit]

    def add_route_references(self, route_name: str, references: str | list[str]) -> list[str]:
        if isinstance(references, str):
            references = [references]
        if route_name not in self.routes:
            self.routes[route_name] = Route(name=route_name, references=[])
        route = self.routes[route_name]
        ids = []
        for ref in references:
            if ref not in route.references:
                route.references.append(ref)
            ids.append(self._add_reference(route_name, ref))
        self._persist_meta()
        return ids

    def get(self, route_name: str) -> Route | None:
        return self.routes.get(route_name)

    def get_route_references(
        self,
        route_name: str = "",
        reference_ids: list[str] | None = None,
        keys: list[str] | None = None,
    ) -> list[dict]:
        reference_ids = reference_ids or []
        keys = keys or []
        results = []
        if keys:
            for key in keys:
                raw = self._redis.get(key)
                if raw:
                    results.append(deserialize_json(raw))
            return results
        if reference_ids:
            for rid in reference_ids:
                raw = self._redis.get(self._ref_key(rid))
                if raw:
                    results.append(deserialize_json(raw))
            return results
        for rid in self._redis.smembers(self._refs_set):
            rid_s = rid.decode() if isinstance(rid, bytes) else rid
            raw = self._redis.get(self._ref_key(rid_s))
            if not raw:
                continue
            ref = deserialize_json(raw)
            if not route_name or ref["route_name"] == route_name:
                results.append(ref)
        return results

    def remove_route(self, route_name: str) -> None:
        if route_name in self.routes:
            del self.routes[route_name]
        refs = self.get_route_references(route_name=route_name)
        self.delete_route_references(route_name=route_name, reference_ids=[r["reference_id"] for r in refs])
        self._persist_meta()

    def delete_route_references(
        self,
        route_name: str = "",
        reference_ids: list[str] | None = None,
        keys: list[str] | None = None,
    ) -> int:
        reference_ids = reference_ids or []
        keys = keys or []
        deleted = 0
        if keys:
            for key in keys:
                self._redis.delete(key)
                deleted += 1
            return deleted
        if reference_ids:
            for rid in reference_ids:
                self._redis.delete(self._ref_key(rid))
                self._redis.srem(self._refs_set, rid)
                self._vector_index.remove(rid)
                deleted += 1
            return deleted
        refs = self.get_route_references(route_name=route_name)
        return self.delete_route_references(
            reference_ids=[r["reference_id"] for r in refs]
        )

    def clear(self) -> None:
        refs = self.get_route_references()
        for ref in refs:
            self._redis.delete(ref["key"])
        self._redis.delete(self._refs_set)
        self._redis.delete(self._meta_key)
        self._vector_index.clear()

    def delete(self) -> None:
        self.clear()

    def update_route_thresholds(self, route_thresholds: dict[str, float | None]) -> None:
        for route_name, th in route_thresholds.items():
            if route_name in self.routes and th is not None:
                self.routes[route_name].distance_threshold = float(th)
        self._persist_meta()

    def update_routing_config(self, routing_config: RoutingConfig) -> None:
        self.routing_config = routing_config
        self._persist_meta()

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "routes": [
                {
                    "name": r.name,
                    "references": r.references,
                    "metadata": r.metadata,
                    "distance_threshold": r.distance_threshold,
                }
                for r in self.routes.values()
            ],
            "routing_config": {
                "max_k": self.routing_config.max_k,
                "aggregation_method": self.routing_config.aggregation_method.value,
            },
        }

    def to_yaml(self, file_path: str, overwrite: bool = True) -> None:
        path = Path(file_path)
        if path.exists() and not overwrite:
            raise FileExistsError(f"{file_path} exists")
        path.write_text(yaml.dump(self.to_dict(), allow_unicode=True), encoding="utf-8")


if __name__ == "__main__":
    routes = [
        Route(name="greeting", references=["hello", "hi", "Hi, good morning"], distance_threshold=0.8),
        Route(name="farewell", references=["bye", "goodbye"], distance_threshold=0.8),
    ]
    router = SemanticRouter(name="router_demo", routes=routes, overwrite=True)
    match = router("Hi, good morning")
    print("match:", match)
