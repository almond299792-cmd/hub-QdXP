"""Semantic LLM response cache."""

from __future__ import annotations

from typing import Any

import redis

from common import (
    VectorIndex,
    create_redis_client,
    current_timestamp,
    default_vectorizer,
    deserialize_json,
    hashify,
    l2_to_cosine_distance,
    serialize_json,
    TextVectorizer,
)


class _IndexPlaceholder:
    """Placeholder for API compatibility with official SemanticCache.index."""

    def __init__(self, name: str):
        self.name = name


class SemanticCache:
    def __init__(
        self,
        name: str = "llmcache",
        distance_threshold: float = 0.1,
        ttl: int | None = None,
        vectorizer: TextVectorizer | None = None,
        filterable_fields: list[dict] | None = None,
        redis_client: redis.Redis | None = None,
        redis_url: str = "redis://localhost:6379",
        connection_kwargs: dict | None = None,
        overwrite: bool = False,
    ) -> None:
        self.name = name
        self._distance_threshold = float(distance_threshold)
        self.ttl = ttl
        self._vectorizer = vectorizer or default_vectorizer()
        self._redis = create_redis_client(redis_client, redis_url, connection_kwargs)
        self.filterable_fields = filterable_fields or []
        self._filter_field_names = [f["name"] for f in self.filterable_fields if "name" in f]

        self._index = _IndexPlaceholder(name)
        self._keys_set = f"{name}:__keys__"
        self._vector_index = VectorIndex(name, self._vectorizer.dims)
        if overwrite:
            self._vector_index.clear()
            self._clear_redis()
        else:
            self._vector_index.load()

    @property
    def distance_threshold(self) -> float:
        return self._distance_threshold

    @property
    def index(self):
        return self._index

    def _entry_key(self, entry_id: str) -> str:
        return f"{self.name}:entry:{entry_id}"

    def _redis_key_field(self, entry_id: str) -> str:
        return f"{self.name}:redis_key:{entry_id}"

    def _clear_redis(self) -> None:
        keys = list(self._redis.smembers(self._keys_set) or [])
        if keys:
            self._redis.delete(*keys)
        self._redis.delete(self._keys_set)

    def set_threshold(self, distance_threshold: float) -> None:
        if not 0 <= float(distance_threshold) <= 2:
            raise ValueError(f"Distance must be between 0 and 2, got {distance_threshold}")
        self._distance_threshold = float(distance_threshold)

    def set_ttl(self, ttl: int | None = None) -> None:
        self.ttl = ttl

    def _parse_filters(self, filter_expression: Any) -> dict | None:
        if filter_expression is None:
            return None
        if isinstance(filter_expression, dict):
            return filter_expression
        return None

    def _filters_match(self, stored: dict | None, required: dict | None) -> bool:
        if not required:
            return True
        if not stored:
            return False
        return all(stored.get(k) == v for k, v in required.items())

    def _load_entry(self, entry_id: str) -> dict | None:
        raw = self._redis.get(self._entry_key(entry_id))
        if not raw:
            return None
        return deserialize_json(raw)

    def store(
        self,
        prompt: str,
        response: str,
        vector: list[float] | None = None,
        metadata: dict | None = None,
        filters: dict | None = None,
        ttl: int | None = None,
    ) -> str:
        vec = vector or self._vectorizer.embed(prompt)
        entry_id = hashify(prompt, filters)
        now = current_timestamp()
        record: dict[str, Any] = {
            "entry_id": entry_id,
            "prompt": prompt,
            "response": response,
            "inserted_at": now,
            "updated_at": now,
            "metadata": metadata,
            "filters": filters,
        }
        for field_name in self._filter_field_names:
            if filters and field_name in filters:
                record[field_name] = filters[field_name]

        key = self._entry_key(entry_id)
        ttl = ttl if ttl is not None else self.ttl
        payload = serialize_json(record)
        if ttl:
            self._redis.setex(key, ttl, payload)
        else:
            self._redis.set(key, payload)

        redis_key = self._redis_key_field(entry_id)
        self._redis.set(redis_key, key)
        self._redis.sadd(self._keys_set, key)
        self._vector_index.add(entry_id, vec)
        return entry_id

    def check(
        self,
        prompt: str | None = None,
        vector: list[float] | None = None,
        num_results: int = 1,
        return_fields: list[str] | None = None,
        filter_expression: dict | None = None,
        distance_threshold: float | None = None,
    ) -> list[dict]:
        if prompt is None and vector is None:
            raise TypeError("Either prompt or vector must be provided.")
        if prompt is not None and not isinstance(prompt, str):
            raise TypeError("Prompt must be a string.")

        query_vec = vector or self._vectorizer.embed(prompt)
        threshold = (
            float(distance_threshold)
            if distance_threshold is not None
            else self._distance_threshold
        )
        required_filters = self._parse_filters(filter_expression)

        hits: list[dict] = []
        for entry_id, l2_dist in self._vector_index.search(query_vec, k=max(num_results * 5, 10)):
            cos_dist = l2_to_cosine_distance(l2_dist)
            if cos_dist > threshold:
                continue
            entry = self._load_entry(entry_id)
            if not entry:
                continue
            if not self._filters_match(entry.get("filters"), required_filters):
                continue
            hit = {
                "entry_id": entry["entry_id"],
                "prompt": entry["prompt"],
                "response": entry["response"],
                "vector_distance": cos_dist,
                "inserted_at": entry["inserted_at"],
                "updated_at": entry["updated_at"],
                "metadata": entry.get("metadata"),
                "filters": entry.get("filters"),
            }
            for field_name in self._filter_field_names:
                if field_name in entry:
                    hit[field_name] = entry[field_name]
            if return_fields:
                hit = {k: v for k, v in hit.items() if k in return_fields}
            hits.append(hit)
            if len(hits) >= num_results:
                break
        return hits

    def clear(self) -> None:
        self._vector_index.clear()
        self._clear_redis()

    def delete(self) -> None:
        self.clear()

    def drop(self, ids: list[str] | None = None, keys: list[str] | None = None) -> None:
        if ids is None and keys is None:
            raise ValueError("At least one of ids or keys must be provided.")
        if ids:
            for entry_id in ids:
                key = self._entry_key(entry_id)
                self._redis.delete(key)
                self._redis.delete(self._redis_key_field(entry_id))
                self._redis.srem(self._keys_set, key)
                self._vector_index.remove(entry_id)
        if keys:
            for key in keys:
                self._redis.delete(key)
                self._redis.srem(self._keys_set, key)

    def expire(self, key: str, ttl: int | None = None) -> None:
        if ttl is not None:
            self._redis.expire(key, ttl)

    def update(self, key: str, **kwargs) -> None:
        raw = self._redis.get(key)
        if not raw:
            return
        entry = deserialize_json(raw)
        entry.update(kwargs)
        entry["updated_at"] = current_timestamp()
        ttl = self._redis.ttl(key)
        payload = serialize_json(entry)
        if ttl and ttl > 0:
            self._redis.setex(key, ttl, payload)
        else:
            self._redis.set(key, payload)


if __name__ == "__main__":
    cache = SemanticCache(name="llm_demo", distance_threshold=0.5)
    cache.clear()
    cache.store(prompt="What is the capital city of France?", response="Paris")
    hits = cache.check(prompt="What is France's capital city?")
    print("hits:", len(hits), hits[0]["response"] if hits else None)
