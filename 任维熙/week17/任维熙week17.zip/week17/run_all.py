"""一键跑通：单元测试 + 四模块演示（无 Docker 时用 fakeredis）。"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> int:
    os.environ.setdefault("USE_MOCK_EMBEDDING", "1")
    os.environ.setdefault("VECTOR_INDEX_PERSIST", "0")
    # 未启动 Docker/Redis 时自动用 fakeredis
    print("=" * 60)
    print("1/2  pytest")
    print("=" * 60)
    r1 = subprocess.call(
        [sys.executable, "-m", "pytest", "tests/test_extensions.py", "-v"],
        cwd=ROOT,
    )
    if r1 != 0:
        return r1

    print()
    print("=" * 60)
    print("2/2  demo.py")
    print("=" * 60)
    env = os.environ.copy()
    env["USE_FAKE_REDIS"] = "1"
    r2 = subprocess.call([sys.executable, "demo.py"], cwd=ROOT, env=env)
    return r2


if __name__ == "__main__":
    raise SystemExit(main())
