"""Tests for Week17 Redis extensions."""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

# Ensure week17 root on path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

os.environ["USE_MOCK_EMBEDDING"] = "1"
os.environ["VECTOR_INDEX_PERSIST"] = "0"

import fakeredis

from EmbeddingsCache import EmbeddingsCache
from SemanticCache import SemanticCache
from SemanticMessageHistory import SemanticMessageHistory
from SemanticRouter import (
    DistanceAggregationMethod,
    Route,
    RoutingConfig,
    SemanticRouter,
)
from common import MockTextVectorizer, VectorIndex, hashify


@pytest.fixture
def redis_client():
    return fakeredis.FakeRedis()


@pytest.fixture(autouse=True)
def isolate_index_dir(tmp_path, monkeypatch):
    import common

    index_dir = tmp_path / "index"
    index_dir.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(common, "INDEX_DIR", index_dir)
    monkeypatch.setattr(common, "VECTOR_INDEX_PERSIST", False)
    yield


class TestCommon:
    def test_hashify_stable(self):
        assert hashify("a", "b") == hashify("a", "b")
        assert hashify("a", "b") != hashify("a", "c")

    def test_mock_embed_same_word_bag(self):
        v = MockTextVectorizer(dims=32)
        e1 = v.embed("What is the capital city of France?")
        e2 = v.embed("What is France's capital city?")
        assert e1 == e2

    def test_vector_index_add_search(self, tmp_path, monkeypatch):
        import common

        index_dir = tmp_path / "index"
        index_dir.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(common, "INDEX_DIR", index_dir)
        idx = VectorIndex("t", 8)
        idx.add("id1", [1.0] + [0.0] * 7)
        hits = idx.search([1.0] + [0.0] * 7, k=1)
        assert hits[0][0] == "id1"


class TestEmbeddingsCache:
    def test_set_get(self, redis_client):
        cache = EmbeddingsCache(name="ec_test", ttl=60, redis_client=redis_client)
        cache.clear()
        vec = [0.5, 0.1, 0.2]
        eid = cache.set("hello", "model-a", vec, metadata={"k": 1})
        hit = cache.get("hello", "model-a")
        assert hit is not None
        assert hit["entry_id"] == eid
        assert hit["embedding"] == vec
        assert hit["metadata"] == {"k": 1}

    def test_exists_drop(self, redis_client):
        cache = EmbeddingsCache(name="ec_test2", redis_client=redis_client)
        cache.clear()
        cache.set("x", "m", [1.0])
        assert cache.exists("x", "m")
        cache.drop("x", "m")
        assert not cache.exists("x", "m")

    def test_mget_mset(self, redis_client):
        cache = EmbeddingsCache(name="ec_test3", redis_client=redis_client)
        cache.clear()
        ids = cache.mset(
            [
                {"content": "a", "model_name": "m", "embedding": [1.0]},
                {"content": "b", "model_name": "m", "embedding": [2.0]},
            ]
        )
        assert len(ids) == 2
        results = cache.mget(["a", "b"], "m")
        assert all(r is not None for r in results)


class TestSemanticCache:
    def test_store_check_france(self, redis_client):
        cache = SemanticCache(
            name="sc_test",
            distance_threshold=0.5,
            redis_client=redis_client,
            overwrite=True,
        )
        cache.store(prompt="What is the capital city of France?", response="Paris")
        hits = cache.check(prompt="What is France's capital city?")
        assert len(hits) >= 1
        assert hits[0]["response"] == "Paris"
        assert "vector_distance" in hits[0]

    def test_check_empty(self, redis_client):
        cache = SemanticCache(name="sc_empty", redis_client=redis_client, overwrite=True)
        assert cache.check(prompt="unknown question") == []

    def test_filters(self, redis_client):
        cache = SemanticCache(
            name="sc_filt",
            redis_client=redis_client,
            overwrite=True,
            filterable_fields=[{"name": "user_id", "type": "tag"}],
        )
        cache.store("q1", "r1", filters={"user_id": "u1"})
        cache.store("q2", "r2", filters={"user_id": "u2"})
        hits = cache.check(prompt="q1", filter_expression={"user_id": "u1"})
        assert len(hits) == 1
        assert hits[0]["response"] == "r1"

    def test_set_threshold(self, redis_client):
        cache = SemanticCache(name="sc_th", redis_client=redis_client, overwrite=True)
        cache.set_threshold(0.01)
        assert cache.distance_threshold == 0.01
        with pytest.raises(ValueError):
            cache.set_threshold(3.0)


class TestSemanticMessageHistory:
    def test_recent_and_relevant(self, redis_client):
        history = SemanticMessageHistory(
            name="mh_test",
            redis_client=redis_client,
            overwrite=True,
            distance_threshold=0.8,
        )
        history.add_messages(
            [
                {"role": "user", "content": "hello"},
                {"role": "llm", "content": "hi there"},
                {"role": "user", "content": "what is the weather going to be today?"},
                {"role": "llm", "content": "I don't know"},
            ]
        )
        recent = history.get_recent(top_k=1)
        assert recent[0]["role"] == "llm"
        rel = history.get_relevant(
            "what is the weather going to be today", top_k=1
        )
        assert rel
        assert "weather" in rel[0]["content"].lower()

    def test_store_and_count(self, redis_client):
        history = SemanticMessageHistory(
            name="mh_test2", redis_client=redis_client, overwrite=True
        )
        history.store("user q", "llm a")
        assert history.count() == 2

    def test_fall_back(self, redis_client):
        history = SemanticMessageHistory(
            name="mh_fb",
            redis_client=redis_client,
            overwrite=True,
            distance_threshold=0.001,
        )
        history.add_message({"role": "user", "content": "only message"})
        rel = history.get_relevant("completely unrelated xyz", top_k=1, fall_back=True)
        assert len(rel) == 1

    def test_invalid_role(self, redis_client):
        history = SemanticMessageHistory(
            name="mh_bad", redis_client=redis_client, overwrite=True
        )
        with pytest.raises(ValueError):
            history.add_message({"role": "invalid", "content": "x"})


class TestSemanticRouter:
    def test_call_greeting(self, redis_client):
        routes = [
            Route(
                name="greeting",
                references=["hello", "hi", "Hi, good morning"],
                distance_threshold=0.8,
            ),
            Route(name="farewell", references=["bye", "goodbye"], distance_threshold=0.8),
        ]
        router = SemanticRouter(
            name="rt_test",
            routes=routes,
            redis_client=redis_client,
            overwrite=True,
            routing_config=RoutingConfig(
                aggregation_method=DistanceAggregationMethod.min
            ),
        )
        match = router("Hi, good morning")
        assert match.name == "greeting"
        assert match.distance is not None

    def test_no_match(self, redis_client):
        routes = [Route(name="greeting", references=["hello"], distance_threshold=0.01)]
        router = SemanticRouter(
            name="rt_nomatch", routes=routes, redis_client=redis_client, overwrite=True
        )
        match = router("quantum physics equation derivation")
        assert match.name is None

    def test_route_many(self, redis_client):
        routes = [
            Route(name="a", references=["foo bar"], distance_threshold=0.9),
            Route(name="b", references=["baz qux"], distance_threshold=0.9),
        ]
        router = SemanticRouter(
            name="rt_many",
            routes=routes,
            redis_client=redis_client,
            overwrite=True,
            routing_config=RoutingConfig(max_k=2),
        )
        matches = router.route_many("foo bar", max_k=2)
        assert len(matches) >= 1

    def test_add_route_references(self, redis_client):
        routes = [Route(name="r1", references=["hello"])]
        router = SemanticRouter(
            name="rt_add", routes=routes, redis_client=redis_client, overwrite=True
        )
        ids = router.add_route_references("r1", ["hi there"])
        assert len(ids) == 1
        refs = router.get_route_references(route_name="r1")
        assert len(refs) >= 2

    def test_to_dict_yaml(self, redis_client, tmp_path):
        routes = [Route(name="greeting", references=["hi"])]
        router = SemanticRouter(
            name="rt_yaml", routes=routes, redis_client=redis_client, overwrite=True
        )
        d = router.to_dict()
        assert d["name"] == "rt_yaml"
        ypath = tmp_path / "routes.yaml"
        router.to_yaml(str(ypath))
        assert ypath.exists()
