"""Semantic message history with recency and relevance retrieval."""

from __future__ import annotations

import uuid
from typing import Any

import redis

from common import (
    VectorIndex,
    create_redis_client,
    current_timestamp,
    default_vectorizer,
    deserialize_json,
    l2_to_cosine_distance,
    new_session_tag,
    serialize_json,
    TextVectorizer,
)

VALID_ROLES = {"system", "user", "llm", "tool"}


class SemanticMessageHistory:
    def __init__(
        self,
        name: str,
        session_tag: str | None = None,
        prefix: str | None = None,
        vectorizer: TextVectorizer | None = None,
        distance_threshold: float = 0.3,
        redis_client: redis.Redis | None = None,
        redis_url: str = "redis://localhost:6379",
        connection_kwargs: dict | None = None,
        overwrite: bool = False,
    ) -> None:
        self._name = name
        self._session_tag = session_tag or new_session_tag()
        self._prefix = prefix or name
        self._distance_threshold = float(distance_threshold)
        self._vectorizer = vectorizer or default_vectorizer()
        self._redis = create_redis_client(redis_client, redis_url, connection_kwargs)

        index_name = f"{name}_{self._session_tag}"
        self._vector_index = VectorIndex(index_name, self._vectorizer.dims)
        if overwrite:
            self._vector_index.clear()
            self._clear_session(self._session_tag)
        else:
            self._vector_index.load()

    @property
    def distance_threshold(self) -> float:
        return self._distance_threshold

    def set_distance_threshold(self, threshold: float) -> None:
        self._distance_threshold = float(threshold)

    def _order_key(self, session_tag: str) -> str:
        return f"{self._prefix}:{session_tag}:_order"

    def _msg_key(self, session_tag: str, entry_id: str) -> str:
        return f"{self._prefix}:{session_tag}:{entry_id}"

    def _clear_session(self, session_tag: str) -> None:
        order_key = self._order_key(session_tag)
        ids = self._redis.lrange(order_key, 0, -1)
        if ids:
            keys = [self._msg_key(session_tag, i.decode() if isinstance(i, bytes) else i) for i in ids]
            self._redis.delete(*keys)
        self._redis.delete(order_key)

    def _validate_roles(self, role: str | list[str] | None) -> list[str] | None:
        if role is None:
            return None
        roles = [role] if isinstance(role, str) else list(role)
        invalid = set(roles) - VALID_ROLES
        if invalid:
            raise ValueError(f"Invalid role(s): {invalid}")
        return roles

    def _format_message(self, raw: dict, as_text: bool = False) -> dict | str:
        if as_text:
            return f"{raw.get('role', '')}: {raw.get('content', '')}"
        return {
            "entry_id": raw["entry_id"],
            "session_tag": raw["session_tag"],
            "role": raw["role"],
            "content": raw["content"],
            "timestamp": raw["timestamp"],
            "tool_call_id": raw.get("tool_call_id"),
            "metadata": raw.get("metadata"),
        }

    def add_message(self, message: dict, session_tag: str | None = None) -> None:
        self.add_messages([message], session_tag)

    def add_messages(self, messages: list[dict], session_tag: str | None = None) -> None:
        tag = session_tag or self._session_tag
        order_key = self._order_key(tag)
        for message in messages:
            role = message["role"]
            if role not in VALID_ROLES:
                raise ValueError(f"Invalid role: {role}")
            entry_id = str(uuid.uuid4())
            vector = self._vectorizer.embed(message["content"])
            record: dict[str, Any] = {
                "entry_id": entry_id,
                "session_tag": tag,
                "role": role,
                "content": message["content"],
                "timestamp": current_timestamp(),
                "tool_call_id": message.get("tool_call_id"),
                "metadata": message.get("metadata"),
                "vector_field": vector,
            }
            key = self._msg_key(tag, entry_id)
            self._redis.set(key, serialize_json(record))
            self._redis.rpush(order_key, entry_id)
            self._vector_index.add(entry_id, vector)

    def store(self, prompt: str, response: str, session_tag: str | None = None) -> None:
        self.add_messages(
            [
                {"role": "user", "content": prompt},
                {"role": "llm", "content": response},
            ],
            session_tag,
        )

    def _load_messages_for_session(self, session_tag: str) -> list[dict]:
        order_key = self._order_key(session_tag)
        ids = self._redis.lrange(order_key, 0, -1)
        messages = []
        for raw_id in ids:
            entry_id = raw_id.decode() if isinstance(raw_id, bytes) else raw_id
            raw = self._redis.get(self._msg_key(session_tag, entry_id))
            if raw:
                messages.append(deserialize_json(raw))
        return messages

    @property
    def messages(self) -> list[dict]:
        raw = self._load_messages_for_session(self._session_tag)
        return [self._format_message(m) for m in raw]  # type: ignore

    def count(self, session_tag: str | None = None) -> int:
        tag = session_tag or self._session_tag
        return self._redis.llen(self._order_key(tag))

    def get_recent(
        self,
        top_k: int = 5,
        as_text: bool = False,
        raw: bool = False,
        session_tag: str | None = None,
        role: str | list[str] | None = None,
    ) -> list[dict] | list[str]:
        if top_k < 0:
            raise ValueError("top_k must be >= 0")
        if top_k == 0:
            return []

        tag = session_tag or self._session_tag
        roles = self._validate_roles(role)
        order_key = self._order_key(tag)
        ids = self._redis.lrange(order_key, 0, -1)
        selected: list[dict] = []
        for raw_id in reversed(ids):
            entry_id = raw_id.decode() if isinstance(raw_id, bytes) else raw_id
            data = self._redis.get(self._msg_key(tag, entry_id))
            if not data:
                continue
            msg = deserialize_json(data)
            if roles and msg["role"] not in roles:
                continue
            selected.append(msg)
            if len(selected) >= top_k:
                break
        selected.reverse()
        if raw:
            return selected
        if as_text:
            return [self._format_message(m, as_text=True) for m in selected]  # type: ignore
        return [self._format_message(m) for m in selected]  # type: ignore

    def get_relevant(
        self,
        prompt: str,
        as_text: bool = False,
        top_k: int = 5,
        fall_back: bool = False,
        session_tag: str | None = None,
        raw: bool = False,
        distance_threshold: float | None = None,
        role: str | list[str] | None = None,
    ) -> list[dict] | list[str]:
        if top_k < 0:
            raise ValueError("top_k must be >= 0")
        if top_k == 0:
            return []

        tag = session_tag or self._session_tag
        roles = self._validate_roles(role)
        threshold = (
            float(distance_threshold)
            if distance_threshold is not None
            else self._distance_threshold
        )
        query_vec = self._vectorizer.embed(prompt)
        hits: list[dict] = []
        for entry_id, l2_dist in self._vector_index.search(query_vec, k=max(top_k * 5, 10)):
            cos_dist = l2_to_cosine_distance(l2_dist)
            if cos_dist > threshold:
                continue
            raw_msg = self._redis.get(self._msg_key(tag, entry_id))
            if not raw_msg:
                continue
            msg = deserialize_json(raw_msg)
            if roles and msg["role"] not in roles:
                continue
            msg = dict(msg)
            msg["vector_distance"] = cos_dist
            hits.append(msg)
            if len(hits) >= top_k:
                break

        if not hits and fall_back:
            return self.get_recent(top_k=top_k, as_text=as_text, raw=raw, session_tag=tag, role=role)

        hits.sort(key=lambda m: m.get("vector_distance", 0))
        if raw:
            return hits
        if as_text:
            return [self._format_message(m, as_text=True) for m in hits]  # type: ignore
        formatted = []
        for m in hits:
            item = self._format_message(m)
            if isinstance(item, dict):
                item["vector_distance"] = m.get("vector_distance")
            formatted.append(item)
        return formatted  # type: ignore

    def clear(self) -> None:
        self._vector_index.clear()
        self._clear_session(self._session_tag)

    def delete(self) -> None:
        self.clear()

    def drop(self, id: str | None = None) -> None:
        tag = self._session_tag
        if id is None:
            recent = self.get_recent(top_k=1, raw=True)
            if not recent:
                return
            id = recent[0]["entry_id"]
        key = self._msg_key(tag, id)
        self._redis.delete(key)
        self._redis.lrem(self._order_key(tag), 0, id)
        self._vector_index.remove(id)


if __name__ == "__main__":
    history = SemanticMessageHistory(name="mh_demo", overwrite=True)
    history.add_messages(
        [
            {"role": "user", "content": "what is the weather going to be today?"},
            {"role": "llm", "content": "I don't know"},
        ]
    )
    rel = history.get_relevant("weather", top_k=1)
    print("relevant:", rel[0]["content"] if rel else None)
